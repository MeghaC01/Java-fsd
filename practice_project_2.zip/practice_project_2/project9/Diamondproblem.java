package practiceProject2;

interface First 
{  
    default void show() 
    { 
        System.out.println("show method of first interface"); 
    } 
} 
interface Second 
{  
    default void show() 
    { 
        System.out.println("show method of second interface"); 
    } 
}  

public class Diamondproblem implements First,Second {
	public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
    	Diamondproblem ob = new Diamondproblem(); 
        ob.show(); 
    } 


}
