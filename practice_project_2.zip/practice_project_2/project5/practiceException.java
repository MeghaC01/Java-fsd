package practiceProject2;
import java.util.Scanner;
class ThrowsDemo
{
	Scanner sc= new Scanner(System.in);
	int[] array = new int[5];
	void arrayEx()throws ArrayIndexOutOfBoundsException
	{
	  System.out.println("enter the index to insert value: ");
	  int i=sc.nextInt();
	  System.out.println("enter the value: ");
	  int v=sc.nextInt();
	  array[i]= v;
	  System.out.println("\nInserted.");
	}
}
public class practiceException extends ThrowsDemo {
	public static void main(String[] args)
    {
		int res;
		Scanner se= new Scanner(System.in);
		System.out.println("enter the numerator: ");
		int a=se.nextInt();
		System.out.println("enter the denominator: ");
		int b=se.nextInt();
		ThrowsDemo T = new ThrowsDemo();
        
        try
        {
        	
            if(b==0)        
                throw(new ArithmeticException("divide by zero exception."));
            else
            {
                res = a / b;
                System.out.print("\nThe result is : " + res+"\n");
            }
            T.arrayEx();
            
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is out of bounds!"); 
        }

        catch(ArithmeticException Ex)
        {
            System.out.print("\nError : " + Ex.getMessage());
        }
        finally
        {
        System.out.print("\nEnd of program.");
        }
    }


}
