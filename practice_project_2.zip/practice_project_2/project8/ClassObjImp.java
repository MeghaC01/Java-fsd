package practiceProject2;

public class ClassObjImp {
	int a,b;
	
	public ClassObjImp(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}
    void sum()
    {
    	System.out.println("The sum of a and b is: "+(a+b));
    }
	@Override
	public String toString() {
		return "ClassObjImp [The valuve of a=" + a + "\n             The value of b=" + b + "]";
	}

	public static void main(String[] args) {
		ClassObjImp c= new ClassObjImp(10, 12);
		System.out.println(c);
		c.sum();
	}

}
