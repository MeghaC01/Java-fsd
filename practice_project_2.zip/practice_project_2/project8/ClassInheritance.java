package practiceProject2;

class BaseClass
{
	int a=40;
	int b=20;
	void Addition()
	{
		System.out.println("The result of addition is "+(a+b));
	}
}
public class ClassInheritance extends BaseClass {
	void Subtraction()
	{
		System.out.println("The result of subtraction is "+(a-b));
	}
	public static void main(String[] args) {
		ClassInheritance c= new ClassInheritance();
		c.Addition();
		c.Subtraction();
	}

}
