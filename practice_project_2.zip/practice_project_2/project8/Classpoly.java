package practiceProject2;

public class Classpoly {
	void sum()
	{
		int a=12;
		int b=13;
		System.out.println("The sum is "+(a+b));
	}
	void sum(int a)
	{
		int b=13;
		System.out.println("The sum is "+(a+b));
	}

	void sum(int a,int b)
	{
		System.out.println("The sum is "+(a+b));
	}
	void sum(double a,double b)
	{
		System.out.println("The sum is "+(a+b));
	}
	public static void main(String[] args) {
		Classpoly c=new Classpoly();
		c.sum();
		c.sum(6);
		c.sum(13, 15);
		c.sum(10.5, 5.5);
		
	}



}
