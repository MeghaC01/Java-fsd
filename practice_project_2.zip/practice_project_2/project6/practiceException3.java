package practiceProject2;
class MyException extends Exception{
	   String str1;
	   MyException(String str2) {
		str1=str2;
		System.out.println("MyException Occurred: "+str1);
	   }
	   
	}

public class practiceException3 {
	public static void main(String args[]){
		try{
			System.out.println("Inside try block");
			throw new MyException("My error Message");
		}
		catch(MyException exp){
			System.out.println("Inside Catch Block") ;
			System.out.println(exp) ;
		}
		finally
		{
			System.out.println("Finally block executed");
		}
	   }


}
