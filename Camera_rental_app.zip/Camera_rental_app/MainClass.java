
import java.util.Scanner;

public class MainClass {
	
	void mainMenu()
	{
		System.out.println("\n   CHOOSE ACTION");
		System.out.println("_____________________");
		System.out.println("1.MY CAMERA\n2.RENT A CAMERA\n3.VIEW ALL CAMERAS\n4.MY WALLET\n5.EXIT");	
	}
	
	
	public static void main(String[] args){
		MainClass mainObj=new MainClass();
		System.out.println("|--------------------------------|");
		System.out.println("|  WELCOME TO CAMERA RENTAL APP  |");
		System.out.println("|--------------------------------|");
		System.out.println("        LOGIN TO CONTINUE");
		System.out.println();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter username : ");
		String username=sc.next();
		System.out.println("Enter password : ");
		String password=sc.next();
		
		UserCamera userCamObj=new UserCamera();
		userCamObj.addUser();
		int check=userCamObj.userCheck(username, password);
		if(check==0)
		{
			System.out.println("INVALID USER!!!");
		}
		else
		{   
			userCamObj.preCameralist();
			boolean shouldExit1 = false;
			while (!shouldExit1)
			{
			mainObj.mainMenu();
			int choiceMain=sc.nextInt();
			if(choiceMain==1)
			{
				boolean shouldExit2 = false;
				while (!shouldExit2)
				{
				System.out.println("\n1.ADD\n2.REMOVE\n3.VIEW MY CAMERAS\n4.GO TO PREVIOUS MENU");
				int choice1=sc.nextInt();
				
				switch(choice1)
				{
				case 1:System.out.println("ENTER CAMERA BRAND :");
					   String brand=sc.next();
					   System.out.println("ENTER THE MODEL :");
					   String model=sc.next();
					   System.out.println("ENTER THE PER DAY PRICE (INR) :");
					   Double price=sc.nextDouble();
					   userCamObj.addCameras(brand,model,price);
					   break;
				case 2:userCamObj.displayCameraList();
					   System.out.println("ENTER THE CAMERA ID TO REMOVE :");
				   	   int id=sc.nextInt();
				   	   userCamObj.removeCamera(id);
				   	   break;
				case 3:userCamObj.displayMyCameras();
					   break;
				case 4:shouldExit2 = true;
				       break;
			    default:System.out.println("INVALD CHOICE!!!");
				}
				}	
			}
			else if(choiceMain==2)
			{
				userCamObj.displayCameraList();
				System.out.println("ENTER THE CAMERA ID YOU WANT TO RENT :");
			   	int id=sc.nextInt();
			   	try 
			   	{
			   		userCamObj.rentCamera(id, username);
			   	}
			   	catch (InsufficientBalanceException e) 
			   	{
			   	    System.out.println(e.getMessage());
			   	    
			   	} 
			   	
			   	
				
			}
			else if(choiceMain==3)
			{
				userCamObj.displayCameraList();
			}
			else if(choiceMain==4)
			{
				userCamObj.Wallet(username);
			}
			else if(choiceMain==5)
			{
				shouldExit1 = true;
			}
			else
			{
				System.out.println("INVALD CHOICE!!!");
			}
		}
		}
	}
}
