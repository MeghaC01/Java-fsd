
public class InsufficientBalanceException extends Exception {
	
	public InsufficientBalanceException(String message) {
		// TODO Auto-generated constructor stub
		 super(message);
	}

}
