import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Camera
{
	String brand;
	String model;
	Double price;
	String status;
}


public class UserCamera extends Validate_User{
	Scanner sc=new Scanner(System.in);
	static int camId=1;
	HashMap<Integer, Camera> cameraList=new HashMap<>();
	Camera camera;
	
	
	void preCameralist()
	{
		
		Camera c1=new Camera();
		c1.brand="sony";
		c1.model="dslr";
		c1.price=500.0;
		c1.status="Available";
		
		Camera c2=new Camera();
		c2.brand="nikon";
		c2.model="2030";
		c2.price=1000.0;
		c2.status="Available";
		
		cameraList.put(camId, c1);
		camId++;
		cameraList.put(camId, c2);
		camId++;
		
	}
	
	
	
	
	void addCameras(String bname,String mod, Double p)
	{
		
		camera=new Camera();
		camera.brand=bname;
		camera.model=mod;
		camera.price=p;
		camera.status="Available";
		cameraList.put(camId, camera);
		camId++;
		System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST");
	}
	
	
	
	
	
	void displayMyCameras()
	{
		int flag1=0;
		System.out.println("CAMERA ID______BRAND___________MODEL__________PRICE(PER DAY)_______STATUS");
		for (Map.Entry<Integer, Camera> entry : cameraList.entrySet()) 
		{
			if(entry.getValue().status=="Rented")
			{
				System.out.println( entry.getKey()+"\t\t"+entry.getValue().brand+"\t\t"+entry.getValue().model
			    		+"\t\t"+entry.getValue().price+"\t\t"+entry.getValue().status);
				flag1=1;
			}  
		}

		if(flag1==0)
		{
			System.out.println("LIST EMPTY!!!");
		}
	}
	
	
	
	
	void displayCameraList()
	{
		System.out.println("CAMERA ID______BRAND___________MODEL__________PRICE(PER DAY)_______STATUS");
		for (Map.Entry<Integer, Camera> entry : cameraList.entrySet()) 
		{
		    System.out.println( entry.getKey()+"\t\t"+entry.getValue().brand+"\t\t"+entry.getValue().model
		    		+"\t\t"+entry.getValue().price+"\t\t"+entry.getValue().status);
		}

	}
	
	
	
	
	void removeCamera(int key)
	{
		if (cameraList.containsKey(key)) {
		cameraList.remove(key);
		System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST");
		}
		else
		{
			System.out.println("INVALID CAMERA ID");
		}
	}
	
	
	
	void rentCamera(int key,String username) throws InsufficientBalanceException
	{
		
	
		if(cameraList.containsKey(key))
		{
			if(cameraList.get(key).status == "Available") 
			{
				Double price= cameraList.get(key).price;
				for (User user : userList) 
				{
					if (user.name.equals(username)) 
					{
	            	
						if(user.balance>=price)
						{
							user.balance=user.balance-price;
							System.out.println("YOUR TRANSACTION FOR CAMERA " + cameraList.get(key).brand + " "
									+ cameraList.get(key).model + " WITH RENT INR." + price + " HAS SUCCESSFULLY COMPLETED");
							cameraList.get(key).status = "Rented";
							
						}
						else
						{
							throw new InsufficientBalanceException("ERROR: TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE. PLEASE DEPOSIT AMOUNT TO YOUR WALLET.");
						}
					}
	        
				}
				
			}
			else
			{
				System.out.println("THE CAMERA IS ALREADY RENTED!!!");
			}
		}
		else
		{
			System.out.println("INVALID CAMERA ID");
			
		}
	}
	
	
	
	
	void Wallet(String username)
	{
		for (User user : userList) 
        {
            if (user.name.equals(username)) 
            {
    
            	System.out.println("YOUR CURRENT WALLET BALANCE IS - INR."+user.balance);
            	System.out.println("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET?(1.YES/2.NO)");
            	int ch=sc.nextInt();
            	if(ch==1)
            	{
            		System.out.println("ENTER THE AMOUNT (INR) - ");
            		double amount=sc.nextInt();
            		user.balance=user.balance+amount;
            		System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE - "+user.balance);
            	}	
            }
	    }
		
	}
}
