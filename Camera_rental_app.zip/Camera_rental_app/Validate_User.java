import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class User
{
	String name;
	String password;
	Double balance;
}
public class Validate_User {
	
	ArrayList<User> userList=new ArrayList<>();
	void addUser()
	{
		User user1=new User();
		user1.name="megha";
		user1.password="123";
		user1.balance=5000.0;
		
		User user2=new User();
		user2.name="remya";
		user2.password="123";
		user2.balance=100.0;
	
		userList.add(user1);
		userList.add(user2);
	}
	
	int userCheck(String Username, String Password)
	{
		boolean isValid = false;
        for (User user : userList) 
        {
            if (user.name.equals(Username) && user.password.equals(Password)) {
                isValid = true;
                break;
            }
        }
        if (isValid) {
            
            return 1;
        }
        else {
        	 return 0;
        }
	}


}
