package practiceMaps;
import java.util.*;
public class mapSample {
	public static void main(String[] args) {
	
		HashMap<Integer,String> hs=new HashMap<Integer,String>();      
	      hs.put(1,"Sunil");    
	      hs.put(2,"Anju");    
	      hs.put(3,"Remya");   
	       
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry s:hs.entrySet()){    
	       System.out.println(s.getKey()+" "+s.getValue());    
	      }
	      
	     
	       
	      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      
	      ht.put(4,"Unni");  
	      ht.put(5,"jeena");  
	      ht.put(6,"Tintu");  
	      ht.put(7,"Snowie");  

	      System.out.println("\nThe elements of HashTable are ");  
	      for(Map.Entry n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      
	      
	      
	      TreeMap<Integer,String> tm=new TreeMap<Integer,String>();    
	      tm.put(8,"Sudesh");    
	      tm.put(9,"Sundha");    
	      tm.put(10,"Anand");       
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry t:tm.entrySet()){    
	       System.out.println(t.getKey()+" "+t.getValue());    
	      }    
	      
	   }  


}
