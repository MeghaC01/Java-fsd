import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class ParallelTests {

    WebDriver driver;
    @Test(groups="Chrome", priority=1)
    public void LaunchChrome() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Downloads\\seleniumjars\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.facebook.com");
        Thread.sleep(2000);
    }
    @Test(groups="Chrome", dependsOnMethods="LaunchChrome",priority=2)
    public void TryFacebook1() throws InterruptedException {
        System.out.println(Thread.currentThread().getId());
        driver.findElement(By.id("email")).sendKeys("ravi10thstudent@gmail.com");
        driver.findElement(By.id("pass")).sendKeys("12345");

        
    }
    
    @Test(groups="edge",priority=3)
    public void LaunchEdge() throws InterruptedException {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\HP\\Downloads\\seleniumjars\\msedgedriver.exe");
        driver = new EdgeDriver();
        driver.get("https://www.facebook.com");
        Thread.sleep(4000);   
    }
    
    @Test(groups="edge", dependsOnMethods="LaunchEdge",priority=4)
    public void TryFacebook2() {
        System.out.println(Thread.currentThread().getId());
        driver.findElement(By.id("email")).sendKeys("ravi10thstudent@gmail.com");
        driver.findElement(By.id("pass")).sendKeys("ravi28394");
    }
}

