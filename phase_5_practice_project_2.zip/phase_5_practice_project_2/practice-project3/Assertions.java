import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assertions {
    
    SoftAssert soft = new SoftAssert();
    WebDriver driver;
    @Test
    public void Launch() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Downloads\\seleniumjars\\chromedriver.exe");
        driver = new ChromeDriver();
        Thread.sleep(3000);
    }

    @Test(dependsOnMethods = { "Launch" })
    public void Facebook() throws InterruptedException {
        driver.get("https://www.facebook.com");
        soft.assertEquals("FB Title", driver.getTitle());   
        Thread.sleep(2000);
    }
    
    @Test(dependsOnMethods = { "Facebook" })
    public void Login() throws InterruptedException {
        driver.findElement(By.id("email")).sendKeys("ravi10thstudent@gmail.com");
        driver.findElement(By.id("pass")).sendKeys("12345");
        //driver.findElement(By.id("loginbutton")).click();
        soft.assertAll();
        Thread.sleep(3000);
    }
}
