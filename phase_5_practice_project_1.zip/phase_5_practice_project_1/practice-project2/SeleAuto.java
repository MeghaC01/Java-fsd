import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleAuto {
public static void main(String[] args) throws InterruptedException {

	System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Downloads\\seleniumjars\\chromedriver.exe");

	WebDriver wd=new ChromeDriver();

	wd.manage().window().maximize();

	facebookAccCreation(wd);
	
	
	googleAccCreation(wd);
}
public static void facebookAccCreation(WebDriver driver) throws InterruptedException {
	String baseUrl = "https://www.facebook.com/r.php?locale=en_GB&display=page";
	
	driver.get(baseUrl);
	
	WebElement firstNameTF = driver.findElement(By.name("firstname"));							
	firstNameTF.sendKeys("firstname");
	

	WebElement lastNameTF = driver.findElement(By.name("lastname"));				
	lastNameTF.sendKeys("lastname");
	
	WebElement mobile = driver.findElement(By.name("reg_email__"));				
	mobile.sendKeys("example@gmail.com");
	
	WebElement password = driver.findElement(By.name("reg_passwd__"));				
	mobile.sendKeys("password123");
	
	String fullXPathOfDayDropDown = 
			"/html/body/div[1]/div[1]/div[1]/div[2]/div/div[2]/div/div/div[1]/form/div[1]/div[5]/div[2]/span/span/select[1]";
	WebElement dayDropDown = driver.findElement(By.xpath(fullXPathOfDayDropDown));
	
	Select select = new Select(dayDropDown);
	select.selectByVisibleText("11");
	
	
	WebElement gender= driver.findElement(By.cssSelector("span > span > input[type='radio'][value='1']"));
	gender.click(); 
	WebElement fbLogoImage = driver.findElement(By.tagName("img"));
	System.out.println("FB Logo src is "+fbLogoImage.getAttribute("src"));
	
	
	
	Thread.sleep(15000);	
	WebElement fbAlreadyLink = driver.findElement(By.linkText("Already have an account?"));
	fbAlreadyLink.click();
	

}

public static void googleAccCreation(WebDriver driver) throws InterruptedException {
	
	String baseUrl = "https://accounts.google.com/signup/v2/createaccount?flowEntry=SignUp";
	
	driver.get(baseUrl);
	

	WebElement firstNameTF = driver.findElement(By.id("firstName"));				
			
	firstNameTF.sendKeys("firname");
	
	
	WebElement lastNameTF = driver.findElement(By.name("lastName"));				
	lastNameTF.sendKeys("lasname");
	
	Thread.sleep(15000);
	WebElement nextButton = driver.findElement(By.className("VfPpkd-vQzf8d"));
	nextButton.click();	
	

	Thread.sleep(15000);				
	driver.close();

}



}

