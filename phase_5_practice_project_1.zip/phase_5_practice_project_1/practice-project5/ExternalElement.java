package com.selenium;


import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExternalElement {
	
	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		ExternalElements(driver);
		ExternalElementsNewTab(driver);
		ExternalElementsIFrame(driver);
		DoubleClick(driver);
		driver.close();
		}
	
	
	static void ExternalElements(WebDriver driver) throws InterruptedException {
		driver.get("C:\\Users\\HP\\Documents\\workspace-spring-tool-suite-4-4.18.0.RELEASE\\Phase5Assisted\\src\\main\\resources\\index.html");
	
		Thread.sleep(5000);
		driver.findElement(By.linkText("See an example alert")).click();
	// alert will appear now, may be in 10 secs
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	// Wait for the alert to be displayed
		wait.until(ExpectedConditions.alertIsPresent());
	// Store the alert in a variable
		Alert alert = driver.switchTo().alert();
		System.out.printf("\n alert text is %s \n", alert.getText());
		Thread.sleep(10000);
		alert.accept();
	}
	
	static void ExternalElementsNewTab(WebDriver driver) throws InterruptedException {

		driver.get("C:\\Users\\HP\\Documents\\workspace-spring-tool-suite-4-4.18.0.RELEASE\\Phase5Assisted\\src\\main\\resources\\index.html");
		Thread.sleep(5000);
		driver.switchTo().newWindow(WindowType.TAB);
		driver.navigate().to("https://www.google.com?q=flowers");
		Thread.sleep(5000);
	}
	
	
	static void ExternalElementsIFrame(WebDriver driver) throws InterruptedException {
		String baseUrl = "C:\\Users\\HP\\Documents\\workspace-spring-tool-suite-4-4.18.0.RELEASE\\Phase5Assisted\\src\\main\\resources\\index.html";
		driver.get(baseUrl);
		driver.switchTo().frame("myframe");
		driver.findElement(By.cssSelector("#docsearch > button > span.DocSearch-Button-Container > span")).click();
		driver.findElement(By.id("docsearch-input")).sendKeys("hello");
		Thread.sleep(5000);
	}
	
	
	static void DoubleClick(WebDriver driver) throws InterruptedException {

		driver.get("C:\\Users\\HP\\Documents\\workspace-spring-tool-suite-4-4.18.0.RELEASE\\Phase5Assisted\\src\\main\\resources\\index.html");
		Thread.sleep(5000);
		WebElement button = driver.findElement(By.id("dblButton"));
		Actions actions = new Actions(driver);
		actions.doubleClick(button).perform();
		Thread.sleep(5000);
		WebElement helloPara = driver.findElement(By.id("xyz"));
		actions.contextClick(helloPara).perform();
		Thread.sleep(5000);
	
	}



}
