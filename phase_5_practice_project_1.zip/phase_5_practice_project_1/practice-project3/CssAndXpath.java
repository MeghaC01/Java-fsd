package com.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CssAndXpath {
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		CSSSelector(driver);
	}
	
	static void CSSSelector(WebDriver driver) {
		
		driver.get("C:\\Users\\HP\\Documents\\workspace-spring-tool-suite-4-4.18.0.RELEASE\\Phase5Assisted\\src\\main\\resources\\index.html");
		
		List<WebElement> inputAdminElements = driver.findElements(By.xpath("//input[contains(@id, 'admin')]"));
		System.out.println("INPUT ADMIN ELEMENTS : " + inputAdminElements.size());
		
		List<WebElement> inputAdminElementsUsingCSSSelectors = driver.findElements(By.cssSelector("input[id*='admin']"));
		System.out.println("INPUT ADMIN ELEMENT USING CSS SELECTOR : " + inputAdminElementsUsingCSSSelectors.size());
		List<WebElement> inputAdminElementsUsingCSSSelectors2 = driver.findElements(By.cssSelector("input[id$='xyz']"));
		System.out.println("ENGING WITH 'xyz' : " + inputAdminElementsUsingCSSSelectors2.size()); 
		WebElement h4SecondChildInsideDiv = driver.findElement(By.cssSelector("div[id='eCommerce'] h4:nth-child(2)"));
		System.out.println("h4SecondChildInsideDiv text is " + h4SecondChildInsideDiv.getText()); 
		
		
	
		WebElement selectMonthElement = driver.findElement(By.id("month"));
		Select selectMonth = new Select(selectMonthElement);
		System.out.printf("\n selectMonth.isMultiple() = %s", 
		selectMonth.isMultiple());
		selectMonth.selectByIndex(0);
		selectMonth.selectByIndex(3);
		selectMonth.selectByIndex(6);
		List<WebElement> allMonthsSelected = selectMonth.getAllSelectedOptions();
		for (WebElement monthOption : allMonthsSelected) {
			System.out.printf("\n option selected = %s", monthOption.getText());
		}
		}


}
