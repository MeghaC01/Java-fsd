import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleAuto {
public static void main(String[] args) {

	System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Downloads\\seleniumjars\\chromedriver.exe");

	WebDriver wd=new ChromeDriver();

	wd.manage().window().maximize();

	wd.get("https://www.amazon.in/");
	
}
}

