package practiceConstructor;

class paraConstr{
	int id;
	String name;
	paraConstr(int i,String n)
	{
		id=i;
		name=n;
	}
	void display() 
	{
		System.out.println("id="+id+ " name="+name);
	}
}
public class conSample {
	
	public static void main(String[] args) {
		paraConstr c1= new paraConstr(5,"Tintu");
		paraConstr c2= new paraConstr(6,"Snowie");
		c1.display();
		c2.display();
		
	}

}
