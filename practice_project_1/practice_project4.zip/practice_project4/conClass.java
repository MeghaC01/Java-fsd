package practiceConstructor;
class defConstr
{
	int id;
	String name;
	void display() 
	{
		System.out.println(id+" "+name);
	}
}

public class conClass {
	
	public static void main(String[] args) {
		defConstr c1= new defConstr();
		defConstr c2= new defConstr();
		c1.display();
		c2.display();
	}

}

