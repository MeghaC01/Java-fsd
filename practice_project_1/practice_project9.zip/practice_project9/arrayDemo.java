package practiceArray;

public class arrayDemo {
	public static void main(String[] args) {

		int a[]= {10,11,12,13,14};
		for(int i=0;i<5;i++) {
		System.out.println("Element of array : "+a[i]);
		}

		int[][] b = {
		            {2, 4, 6, 8}, 
		            {3, 6, 9} 
		            };
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
		      System.out.println("\nLength of row 2: " + b[1].length);
		      }


}
