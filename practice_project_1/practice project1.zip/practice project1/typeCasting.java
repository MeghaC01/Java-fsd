package practiceCasting;

public class typeCasting {
	public static void main(String[] args) {
		System.out.println("Implicit Casting");
		System.out.println("___________________");
		char a='M';
		System.out.println("value of a= "+a);
		int b= a;
		System.out.println("value of b= "+b);
		float c=b;
		System.out.println("value of c= "+c);
		long d=a;
		System.out.println("value of d= "+d);
		double e=d;
		System.out.println("value of e= "+e);
		System.out.println("\n");
		System.out.println("Explicit Casting");
		System.out.println("___________________");
		double f=15.5;
		int g=(int)f;
		System.out.println("value of f= "+f);
		System.out.println("value of g= "+g);

		
	}

}
