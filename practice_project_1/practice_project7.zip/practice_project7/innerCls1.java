package practiceInnerClass;

public class innerCls1 {
	
	private String msg="Welcome to Java"; 
	 
	 class Inner{  
		 void display()
		 {
			 System.out.println(msg+", Let us start learning!!!");}  
	 	 }  


	public static void main(String[] args) {

		innerCls1 obj=new innerCls1();
		innerCls1.Inner in=obj.new Inner();  
		in.display();  
	}


}
