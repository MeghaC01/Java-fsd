package practiceInnerClass;

public class innerCls2 {
	private String msg="Inner Classes";

	 void display()
	 {
		 class Inner
		 {  
			 void msg()
			 {
				 System.out.println(msg);
			 }  
	     }  
	  
	  Inner i=new Inner();  
	  i.msg();  
	 }  

	 
	public static void main(String[] args) {
		innerCls2  obj=new innerCls2 ();  
		obj.display();  
		}


}
