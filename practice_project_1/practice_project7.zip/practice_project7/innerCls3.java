package practiceInnerClass;

abstract class sample
{
	public abstract void display();
}

public class innerCls3 {
	public static void main(String[] args) {
		sample i = new sample() 
		{
		         public void display() 
		         {
		            System.out.println("Anonymous Inner Class");
		         }
		};
		      i.display();
    }


}
