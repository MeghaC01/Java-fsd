package practiceAccessSpecifiers;

class defaultAccessSpec {
	
	 void display() 
	    { 
	        System.out.println("Display function in defalut access specifier"); 
	    } 
}
