package practiceAccessSpecifiers;

public class protectedAccessSpec {
	protected void diplay()
	{
		System.out.println("This is protected access specifier");
	}

}
