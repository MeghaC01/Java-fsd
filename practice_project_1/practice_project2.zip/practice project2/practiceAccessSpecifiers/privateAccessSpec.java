package practiceAccessSpecifiers;

class privateAccessSpec {
	
	private void display() 
	    { 
	        System.out.println("Display function in private access specifier"); 
	    } 
}
