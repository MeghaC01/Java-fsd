package practiceAccessSpecifiers;

public class accessSpecifiers2 {
	public static void main(String[] args) {
		System.out.println("Private Access Specifier:");
		privateAccessSpec b=new privateAccessSpec();
		//b.display();
	}

}
