package practiceAccessSpecifiers;

public class publicAccessSpec {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 


}
