package practiceAccessSpecifiers;

public class accessSpecifiers1 {
public static void main(String[] args) {
	System.out.println("Dafault Access Specifier:");
	defaultAccessSpec a = new defaultAccessSpec(); 		  
    a.display(); 

}
}
