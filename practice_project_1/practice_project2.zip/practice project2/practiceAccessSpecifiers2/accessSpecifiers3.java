package practiceAccessSpecifiers2;

import practiceAccessSpecifiers.*;

public class accessSpecifiers3 extends protectedAccessSpec{
	public static void main(String[] args) {
		System.out.println("Protected Access Specifier:");
		accessSpecifiers3 c=new accessSpecifiers3();
		c.diplay();
	}

}
