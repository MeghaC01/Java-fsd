package practiceAccessSpecifiers2;
import practiceAccessSpecifiers.*;
public class accessSpecifiers4 {
public static void main(String[] args) {
	System.out.println("Public Access Specifier:");
	publicAccessSpec d =new publicAccessSpec();
	d.display();
}
}
