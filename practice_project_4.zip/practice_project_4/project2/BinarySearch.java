package practiceProject4;

import java.util.Scanner;

public class BinarySearch {
    
    public static int Binarysearch(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;
        
        while (low <= high) {
            int mid = (low + high) / 2;
            if (arr[mid] == key) {
                return mid;
            } 
            else if (arr[mid] < key) {
                low = mid + 1;
            } 
            else {
                high = mid - 1;
            }
        }
        return -1; 
    }
    
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter the no.of elements in the array: ");
    	int n=sc.nextInt();
    	int[] arr = new int[n];
    	for(int i=0;i<n;i++)
    	{
    		System.out.println("enter element: ");
    		arr[i]=sc.nextInt();
    	}
    	for(int i:arr)
    	{
    		System.out.print(i+"\t");
    	}
        System.out.println("\nenter key to be searched: ");
        int key = sc.nextInt();
        
        int index = Binarysearch(arr, key);
        
        if (index == -1) {
            System.out.println("Key not found");
        } else {
            System.out.println("Key found at position " + (index+1));
        }
    }
}
