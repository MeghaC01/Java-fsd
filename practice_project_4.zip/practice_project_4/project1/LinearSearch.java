package practiceProject4;

import java.util.Scanner;

public class LinearSearch {
    
    public static int search(int[] arr, int key) {
        for (int i = 0; i < arr.length; i++) 
        {
            if (arr[i] == key)
            {
                return i;
            }
        }
        return -1; 
    }
    
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter the no.of elements in the array: ");
    	int n=sc.nextInt();
    	int[] arr = new int[n];
    	for(int i=0;i<n;i++)
    	{
    		System.out.println("enter element: ");
    		arr[i]=sc.nextInt();
    	}
    	for(int i:arr)
    	{
    		System.out.print(i+"\t");
    	}
        System.out.println("\nenter key to be searched: ");
        int key = sc.nextInt();
        int index = search(arr, key);        
        if (index == -1) {
            System.out.println("Key not found");
        } else {
            System.out.println("Key found at position " + (index+1));
        }
    }
}
