package practiceProject4;

import java.util.Scanner;

public class SelectionSort {
    
    public static void selectionsort(int[] arr) {
        int n = arr.length;
        
        for (int i = 0; i < n - 1; i++) {
            int min = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[min]) {
                    min = j;
                }
            }
            int temp = arr[min];
            arr[min] = arr[i];
            arr[i] = temp;
        }
    }
    
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter the no.of elements in the array: ");
    	int n=sc.nextInt();
    	int[] arr = new int[n];
    	for(int i=0;i<n;i++)
    	{
    		System.out.println("enter element: ");
    		arr[i]=sc.nextInt();
    	}
    	System.out.println("\nBefore sorting:");
    	for(int i:arr)
    	{
    		System.out.print(i+"\t");
    	}
        
        
        selectionsort(arr);
        
        System.out.println("\nSorted array:");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + "\t");
        }
    }
}
