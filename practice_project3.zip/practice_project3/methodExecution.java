package practiceMethods;

public class methodExecution {
int v=200;
public int multiplyNumbers(int a, int b)
{
	int mul=a*b;
	return mul;
}

int operation(int v)
{
	v=v*10/100;
	return v;
}

public void area(int a, int b) 
{
	System.out.println("Area of Triangle : "+(0.5*a*b));
}

public void area(int r)
{
	System.out.println("Area of Circle : "+(3.14*r*r));
}
public static void main(String[] args) {
	methodExecution md=new methodExecution();
	int z= md.multiplyNumbers(5, 20);
	System.out.println("multiplied value is: "+ z);
	System.out.println("\n");
	System.out.println("value of v before operation function is called: "+ md.v);
	md.operation(150);
	System.out.println("value of v after operation function is called: "+ md.v);
	System.out.println("\n");
	md.area(10,5);
	md.area(8);
}
}
