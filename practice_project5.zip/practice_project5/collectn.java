package practiceCollection;
import java.util.*;
public class collectn {
	public static void main(String[] args) {
		System.out.println("ArrayList");
		ArrayList<String> city=new ArrayList<String>();   
	      city.add("kerala");
	      city.add("chennai");    	   
	      System.out.println(city);  
		
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> vect = new Vector();
	      vect.addElement(20); 
	      vect.addElement(30); 
	      System.out.println(vect);
		
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> dept=new LinkedList<String>();  
	      dept.add("MCA");  
	      dept.add("Commerce");  	      
	      Iterator<String> itr=dept.iterator();  
	      while(itr.hasNext())
	      {  
	       System.out.println(itr.next());  
	       
	       
	       System.out.println("HashSet");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(101);  
	       set.add(103);  
	       set.add(102);
	       set.add(104);
	       System.out.println(set);
	       
	       System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(11);  
	       set2.add(13);  
	       set2.add(12);
	       set2.add(14);	       
	       System.out.println(set2);
	       System.out.println("\n");
	      	} 
	      }  


}
