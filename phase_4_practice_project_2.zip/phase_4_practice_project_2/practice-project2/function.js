
 

    function add(x, y) {
        return x + y;
    };

    let result = add(4, 5); // 9
    console.log(result);


    function Car(name, color) {
        this.name = name;
        this.color = color;

        this.display = function () {
            return "[" + this.name + ", " + this.color + "]"
        }
    };

    car1 = new Car("Maruti", "red");
    console.log(car1.name);

    console.log(car1.display());

   
    console.log("\n\n***** After ES6 ********");

    
    // Arrow function for the above add function
    add_new = (x, y) => {
        return x + y;
    };

    // another approach
    add_new1 = (x, y) => x + y;

    console.log(add_new(40, 50));
    console.log(add_new1(400, 500));

    // Creating Objects using ES6 features
    console.log("\n\n***** Creating Objects using ES6 features ********");

    class Bus {

        constructor(name, color) {
            this.name = name;
            this.color = color;
        }

        display() {
            return "[" + this.name + ", " + this.color + "]"
        }

    };


    bus1 = new Bus("Tata", "red");
    console.log(bus1.name);

    console.log(bus1.display());


    // Creating Objects using ES6 features
    console.log("\n\n***** Inheritance in ES6 ********");

    class LuxuryBus extends Bus {

        constructor(name, color, hasAC, hasVideoPlayer){
            super(name, color);
            this.hasAC = hasAC;
            this.hasVideoPlayer=hasVideoPlayer;
        }

        // override the super class's display
        // using traditional way of writing functions 
        // display() {
        //     return super.display() + ", [AC="  + this.hasAC + ",VIDEO=" + this.hasVideoPlayer + " ]";
        // }

        // using modern (ES6) way of writing functions
        display = () =>  super.display() + ", [AC="  + this.hasAC + ",VIDEO=" + this.hasVideoPlayer + " ]";
        
    };


    luxBus1 = new LuxuryBus("Toyota", "purple", true, false);
    console.log(luxBus1.name);

    console.log(luxBus1.display());    

