import java.util.Scanner;

public class Stack 
{ 
    	static final int MAX = 1000; 
    	int top; 
    	int a[] = new int[MAX];  
  	    
    	Stack() 
    	{ 
        		top = -1; 
    	} 
    	boolean push(int x) 
    	{ 
        		if (top >= (MAX-1)) 
        		{ 
            			System.out.println("Stack Overflow"); 
            			return false; 
        		} 
        		else
        		{ 
            			a[++top] = x; 
            			System.out.println(x + " pushed into stack"); 
            			return true; 
        		} 
    	} 
    	int pop() 
    	{ 
        		if (top < 0) 
        		{ 
            			System.out.println("Stack Underflow"); 
            			return 0; 
        		} 
        		else
        		{ 
            			int x = a[top--]; 
            			return x; 
        		} 
    	} 
    	void display()
    	{
    		for( int i=0;i<=top;i++)
    		{
    			System.out.print(a[i]+"\t");
    		}
    		
    	}
    
    	public static void main(String args[])
{
        		Stack s = new Stack(); 
        		Scanner sc= new Scanner(System.in);
        		while(true)
        		{
        		System.out.println("\n1.push\n2.pop\n3.display stack\n4.exit");
        		System.out.println("enter the choice number: ");
        		int a=sc.nextInt();
        		
        		
        		switch(a)
        		{
        			case 1: System.out.println("enter element to push :");
							int b=sc.nextInt();
							s.push(b); 
							break;
        			case 2: System.out.println(s.pop() + " Popped from stack"); 
        					break;
        			case 3: s.display();
        					break;
        			case 4: System.out.println("exiting...");
        					System.exit(0);
        					break;
        			default: System.out.println("invalid input!!!");
        		}
        		
        		}		 
 
    	}
}