import java.util.Scanner;

public class ArrayRotation {
void arrayrotate(int[] nums)
{
	int[] result = new int[nums.length];
	int a=(nums.length)-1;
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<=a;j++)
		{
			if(j==a)
			{
				result[0]=nums[j];
			}
			else
			{
				result[j+1]=nums[j];
			}
		}
		System.arraycopy( result, 0, nums, 0, nums.length );
	}
	System.out.println("Array after rotation");
	for(int c:result)
	{
		System.out.print(c+"\t");
	}
		
}
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the no.of elements in the array");
	int n=sc.nextInt();
	int[] nums = new int[n];
	for(int i=0;i<n;i++)
	{
		System.out.println("enter the array elements: ");
		nums[i]=sc.nextInt();
		
	}
	ArrayRotation ar=new ArrayRotation();
	ar.arrayrotate(nums);
	
	
}
}
