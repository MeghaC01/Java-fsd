import java.util.Scanner;
import java.util.Arrays;
public class smallest4thelement {
	void arraysearch()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no.of elements in the array");
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("enter array element: ");
			arr[i]=sc.nextInt();
		}
		Arrays.sort(arr);
		
		
		int c=1;
		int flag=0;
		int b=arr[0];
		for(int i=1;i<n;i++)
		{
			if(arr[i]==b)
			{
				continue;
			}
			else
			{
				b=arr[i];
				c++;
				if(c==4)
				{
					flag=1;
					System.out.println("the 4th smallest element is: "+arr[i]);
					break;
				}
			}
		}
		if(flag==0)
		{
			System.out.println("there is no 4th smallest element!!");
		}
		
	}
	public static void main(String[] args) {
		smallest4thelement sm=new smallest4thelement();
		sm.arraysearch();
	}
		
}


