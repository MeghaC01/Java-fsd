import java.util.Scanner;

public class sumof_n_elements {
	void sum(int[] arr,int a,int b)
	{
		int s=0;
		for(int i=a;i<=b;i++)
		{
			s=s+arr[i];
		}
		System.out.println("The sum of elements is: "+s);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no.of elements in the array: ");
		int n=sc.nextInt();
		int[] arr=new int[n];
		for (int i=0;i<n;i++)
		{
			System.out.println("enter elements: ");
			arr[i]=sc.nextInt();
		}
		sumof_n_elements ss=new sumof_n_elements();
		System.out.println("enter L limit: ");
		int l=sc.nextInt();
		System.out.println("enter R limit: ");
		int r=sc.nextInt();
		ss.sum(arr, l, r);
		}
		
	

}
