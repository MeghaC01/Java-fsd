import java.util.Scanner;

public class MatrixMultiply {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the row count of 1st matrix");
		int r1=sc.nextInt();
		System.out.println("enter the column count of 1st matrix");
		int c1=sc.nextInt();
		int[][] a=new int[r1][c1];
		for (int i=0;i<r1;i++)
		{
			for (int j=0;j<c1;j++)
			{
				System.out.println("enter "+i+""+j+"th element");
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println("enter the row count of 2ndt matrix");
		int r2=sc.nextInt();
		System.out.println("enter the column count of 2nd matrix");
		int c2=sc.nextInt();
		int[][] b=new int[r2][c2];
		for (int i=0;i<r2;i++)
		{
			for (int j=0;j<c2;j++)
			{
				System.out.println("enter "+i+""+j+"th element");
				b[i][j]=sc.nextInt();
			}
		}
		int[][] c=new int[r1][c2];
		if(c1!=r2)
		{
			System.out.println("Multiplication not possible!!");
			
		}
		else
		{
			
			for (int i=0;i<r1;i++)
			{
				for (int j=0;j<c2;j++)
				{
					for (int k = 0; k < c1; k++) 
					{
					      c[i][j] += a[i][k] * b[k][j];
					}

				}
			}
			System.out.println("First matrix: ");
			for (int i=0;i<r1;i++)
			{
				for (int j=0;j<c1;j++)
				{
					System.out.print(a[i][j]+"\t");
				}
				System.out.print("\n");
			}
			
			System.out.println("Second matrix: ");
			for (int i=0;i<r2;i++)
			{
				for (int j=0;j<c2;j++)
				{
					System.out.print(b[i][j]+"\t");
				}
				System.out.print("\n");
			}
			
			System.out.println("The product is: ");
			for (int i=0;i<r1;i++)
			{
				for (int j=0;j<c2;j++)
				{
					System.out.print(c[i][j]+"\t");
				}
				System.out.print("\n");
			}
			
		}
	}

}
