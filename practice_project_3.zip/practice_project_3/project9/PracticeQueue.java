import java.util.LinkedList;
import java.util.Queue;
public class PracticeQueue
{
		public static void main(String[] args) 
		{
        		Queue<String> locQueue = new LinkedList<>();
        		locQueue.add("India");
        		locQueue.add("China");
        		locQueue.add("Singapore");
        		locQueue.add("America");
        		locQueue.add("England");
        		System.out.println("Queue is : " + locQueue);
        		System.out.println("Head of Queue : " + locQueue.peek());
        		locQueue.remove();
        		System.out.println("After removing Head of Queue : " + locQueue);
        		System.out.println("Size of Queue : " + locQueue.size());
    	}
}
